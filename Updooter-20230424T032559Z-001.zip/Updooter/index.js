const Discord = require("discord.js");
const client = new Discord.Client();
const Enmap = require("enmap");
const myEnmap = new Enmap();
const DB = require("better-sqlite-pool");

client.karma = new Enmap({name: 'test' });

client.on("ready", () => {
  console.log("Updooter Activated");
  globalreacts = 0;
  activeservers = 0;
  serverlist = []
  if(myEnmap.isReady) { 
  console.log("Data Ready");
  
  }else {
  console.log("Data Not Loaded");
  }
  //Set bot activity
  client.user.setActivity(`with reactions | ${prefix}help`);
  //Used to find how many servers my bot is in
  console.log(`On ${client.guilds.cache.size} servers`);
});
client.on('messageReactionAdd', (reaction, user, message) => {
  if(reaction.emoji.name === "🔼") {
    if (user.id === reaction.message.author.id) {
      const key = `${reaction.message.author.id}`;
        client.karma.ensure(key, {
        user: reaction.message.author.id,
        karma: 0
      });
      client.karma.dec(key, "karma");
      }else
        console.log(reaction.message.author.id);
        globalreacts += 1;
        const key = `${reaction.message.author.id}`;
          client.karma.ensure(key, {
          user: reaction.message.author.id,
          karma: 0
        });
        client.karma.inc(key, "karma");
  }else
  if(reaction.emoji.name === "🔽") {
    if (user.id === reaction.message.author.id) {
      const key = `${reaction.message.author.id}`;
      client.karma.ensure(key, {
        user: reaction.message.author.id,
        karma: 0
      });
      client.karma.inc(key, "karma");
    }else
      console.log(reaction.message.author.id);
      globalreacts += 1;
      const key = `${reaction.message.author.id}`;
        client.karma.ensure(key, {
        user: reaction.message.author.id,
        karma: 0
      });
      client.karma.dec(key, "karma");
  } 
});
client.on('messageReactionRemove', (reaction, user, message) => {
    if(reaction.emoji.name === "🔼") {
      if (user.id === reaction.message.author.id) {
        const key = `${reaction.message.author.id}`;
        client.karma.ensure(key, {
          user: reaction.message.author.id,
          karma: 0
        });
        client.karma.inc(key, "karma");
      }else
        globalreacts -= 1;
        console.log(reaction.message.author.id);
        const key = `${reaction.message.author.id}`;
          client.karma.ensure(key, {
          user: reaction.message.author.id,
          karma: 0
        });
        client.karma.dec(key, "karma");
    }else
    if(reaction.emoji.name === "🔽") {
      if (user.id === reaction.message.author.id) {
        const key = `${reaction.message.author.id}`;
        client.karma.ensure(key, {
          user: reaction.message.author.id,
          karma: 0
        });
        client.karma.dec(key, "karma");
      }else
        globalreacts -= 1;
        console.log(reaction.message.author.id);
        const key = `${reaction.message.author.id}`;
          client.karma.ensure(key, {
          user: reaction.message.author.id,
          karma: 0
        });
        client.karma.inc(key, "karma");
    }
});
const prefix = "ud."
client.on("message", (message) => {
if (!serverlist.includes(message.guild.id)) {
  console.log(message.guild.id);
  serverlist.push(message.guild.id);
  activeservers += 1;
}
function react() {
  message.react("🔽");
  globalreacts = globalreacts + 1
}
if(message.author.bot) return;
if (message.attachments.size > 0) {
    setTimeout(react, 500);
    message.react("🔼");
}else
  if (message.content.startsWith("'")) {
    setTimeout(react,500);
    message.react("🔼");
  }else
//Prefix commands
if (message.content.startsWith(prefix + "reactions")) {
  responsetime = new Date().getTime() - message.createdTimestamp
  message.channel.send("There have been `"+ globalreacts +"` reactions made today. Active Server Count: `" + activeservers + "` Response Time: `" + responsetime + "` ms");
  console.log("Pinged");
 }else
  if (message.content.startsWith(prefix + "github")) {
    message.channel.send("<https://github.com/bdemer>");
  }else
   if (message.content.startsWith(prefix + "website")) {
    message.channel.send("<https://danieldemer.com>");
  }else
   
  if (message.content.startsWith(prefix + "karma")) {
  const key = `${message.author.id}`;
  try {
    message.channel.send(`You currently have ${client.karma.get(key, "karma")} karma. This will reset every day.`);
  }
  catch(EnmapPathError) {
    message.channel.send("You currently have no karma!")
  }
 
  }else
  if (message.content.startsWith(prefix + "help")) {
    message.channel.send({embed: {
    color: 16777215,
    description: "**Prefix**: `"+prefix+"` This bot was forked from Reddicord: https://repl.it/@jamxu88/Reddicord \n **General Commands**: \n `website`- View the Updooter creators' website \n `reactions`- See total reactions for the day \n `github`- View the github repo maintained by the Updooter creator \n \n**Karma Commands**: \n `karma`- Check your karma \n \n**How do I get Karma?**- Just post an image, gif, link, or video in a text channel with reactions enabled, and get some upvotes. Posting a joke? Just start your message with `'` (single quote) \n Karma will reset once a day."
    }});
  }else
  if (message.content.includes('https://')) {
    setTimeout(react,500);
    message.react("🔼");
  }
});

client.login('MzM2OTEzMjAzMjY5MjA2MDE3.WW483w.TmvkMa_hY3EHUVTyxkDc80dKMaU');
